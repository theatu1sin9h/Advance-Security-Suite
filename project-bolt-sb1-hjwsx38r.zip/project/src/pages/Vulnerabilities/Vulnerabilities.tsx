import React from 'react';
import { useScan } from '../../context/ScanContext';
import VulnerabilityList from '../../components/Vulnerabilities/VulnerabilityList';
import { Shield } from 'lucide-react';

const Vulnerabilities: React.FC = () => {
  const { currentScan } = useScan();

  if (!currentScan) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 flex flex-col items-center justify-center min-h-[500px]">
        <Shield size={48} className="text-gray-300 dark:text-gray-600 mb-4" />
        <p className="text-lg text-gray-500 dark:text-gray-400">No vulnerabilities to display</p>
        <p className="mt-2 text-sm text-gray-400 dark:text-gray-500">
          Run a scan to identify security vulnerabilities
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Vulnerabilities</h1>
        <p className="text-gray-500 dark:text-gray-400">Comprehensive list of detected security vulnerabilities</p>
      </div>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <VulnerabilityList vulnerabilities={currentScan.vulnerabilities} />
      </div>
    </div>
  );
};

export default Vulnerabilities;