import React from 'react';
import { useScan } from '../../context/ScanContext';
import { formatDistance } from '../../utils/dateUtils';
import { History as HistoryIcon, Shield } from 'lucide-react';

const History: React.FC = () => {
  const { scanResults, selectScan, currentScan } = useScan();

  if (scanResults.length === 0) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 flex flex-col items-center justify-center min-h-[500px]">
        <Shield size={48} className="text-gray-300 dark:text-gray-600 mb-4" />
        <p className="text-lg text-gray-500 dark:text-gray-400">No scan history available</p>
        <p className="mt-2 text-sm text-gray-400 dark:text-gray-500">
          Your scan history will appear here once you start scanning
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Scan History</h1>
        <p className="text-gray-500 dark:text-gray-400">Review and compare previous security scans</p>
      </div>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <div className="space-y-4">
          {scanResults.map(scan => (
            <button
              key={scan.id}
              onClick={() => selectScan(scan.id)}
              className={`
                w-full text-left p-4 rounded-lg transition-colors duration-200
                ${currentScan?.id === scan.id 
                  ? 'bg-blue-50 dark:bg-blue-900/20 border-l-4 border-blue-500' 
                  : 'bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-650'}
              `}
            >
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center">
                    <h3 className="text-lg font-medium">{scan.url}</h3>
                    <span className="ml-3 text-sm text-gray-500 dark:text-gray-400">
                      {formatDistance(scan.scanDate)}
                    </span>
                  </div>
                  <div className="mt-2 grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">IP Address</p>
                      <p className="font-medium">{scan.ipAddress}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Duration</p>
                      <p className="font-medium">{(scan.duration / 1000).toFixed(1)}s</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Vulnerabilities</p>
                      <p className="font-medium">{scan.vulnerabilities.length}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">Security Score</p>
                      <p className={`font-medium ${
                        scan.securityScore >= 80 ? 'text-green-500' : 
                        scan.securityScore >= 60 ? 'text-yellow-500' : 'text-red-500'
                      }`}>{scan.securityScore}</p>
                    </div>
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default History;