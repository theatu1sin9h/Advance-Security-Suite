import React from 'react';
import ScanForm from '../../components/Scan/ScanForm';
import ScanResultsPanel from '../../components/Scan/ScanResultsPanel';
import ScanHistory from '../../components/Scan/ScanHistory';
import { useScan } from '../../context/ScanContext';

const Dashboard: React.FC = () => {
  const { currentScan, isScanning } = useScan();
  
  return (
    <div className="space-y-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Security Dashboard</h1>
        <p className="text-gray-500 dark:text-gray-400">Scan and analyze websites for security vulnerabilities</p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <ScanForm />
          {!isScanning && <ScanHistory className="mt-6" />}
        </div>
        
        <div className="lg:col-span-2">
          <ScanResultsPanel />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;