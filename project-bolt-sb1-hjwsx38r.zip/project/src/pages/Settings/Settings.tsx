import React from 'react';
import { useScan } from '../../context/ScanContext';
import { useTheme } from '../../context/ThemeContext';
import { Moon, Sun } from 'lucide-react';

const Settings: React.FC = () => {
  const { scanOptions, setScanOptions } = useScan();
  const { theme, toggleTheme } = useTheme();

  return (
    <div className="space-y-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-gray-500 dark:text-gray-400">Configure application preferences and scan settings</p>
      </div>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <div className="space-y-8">
          <div>
            <h2 className="text-lg font-medium mb-4">Appearance</h2>
            <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <div>
                <p className="font-medium">Dark Mode</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Toggle between light and dark theme</p>
              </div>
              <button
                onClick={toggleTheme}
                className={`
                  p-2 rounded-full transition-colors duration-200
                  ${theme === 'dark' ? 'bg-gray-600 text-white' : 'bg-gray-200 text-gray-900'}
                `}
              >
                {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
              </button>
            </div>
          </div>

          <div>
            <h2 className="text-lg font-medium mb-4">Scan Settings</h2>
            <div className="space-y-4">
              <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <p className="font-medium mb-2">Default Scan Timeout</p>
                <input
                  type="range"
                  min="10"
                  max="300"
                  step="10"
                  value={scanOptions.timeout}
                  onChange={(e) => setScanOptions({ timeout: parseInt(e.target.value) })}
                  className="w-full mb-2"
                />
                <div className="flex justify-between text-sm text-gray-500 dark:text-gray-400">
                  <span>10s</span>
                  <span>{scanOptions.timeout}s</span>
                  <span>300s</span>
                </div>
              </div>

              <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <p className="font-medium mb-2">Default Scan Depth</p>
                <div className="flex gap-2">
                  {['light', 'medium', 'deep'].map(depth => (
                    <button
                      key={depth}
                      onClick={() => setScanOptions({ depth: depth as 'light' | 'medium' | 'deep' })}
                      className={`
                        px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200
                        ${scanOptions.depth === depth
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-gray-200'}
                      `}
                    >
                      {depth.charAt(0).toUpperCase() + depth.slice(1)}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;