import React from 'react';
import { useScan } from '../../context/ScanContext';
import ReportCharts from '../../components/Reports/ReportCharts';
import { Shield } from 'lucide-react';

const Reports: React.FC = () => {
  const { currentScan } = useScan();

  if (!currentScan) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 flex flex-col items-center justify-center min-h-[500px]">
        <Shield size={48} className="text-gray-300 dark:text-gray-600 mb-4" />
        <p className="text-lg text-gray-500 dark:text-gray-400">No scan data available</p>
        <p className="mt-2 text-sm text-gray-400 dark:text-gray-500">
          Run a scan first to view detailed reports
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Security Reports</h1>
        <p className="text-gray-500 dark:text-gray-400">Detailed analysis and insights from your security scans</p>
      </div>
      
      <ReportCharts scan={currentScan} showFullReport={true} />
    </div>
  );
};

export default Reports;