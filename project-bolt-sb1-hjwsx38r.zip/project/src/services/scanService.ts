import { ScanOptions, ScanResult, ToolType, Vulnerability, PortInfo, SeverityLevel } from '../types/scan';

// Helper function to generate mock data
const generateMockVulnerabilities = (count: number, toolType: ToolType): Vulnerability[] => {
  const severityLevels: SeverityLevel[] = ['critical', 'high', 'medium', 'low', 'info'];
  const vulnerabilityNames = {
    nmap: ['Open SSH Port', 'Outdated TLS Version', 'Telnet Enabled', 'FTP Anonymous Access'],
    wapiti: ['SQL Injection', 'XSS Vulnerability', 'CSRF Token Missing', 'Directory Traversal'],
    nessus: ['Outdated Software', 'Default Credentials', 'Missing Security Headers', 'Information Disclosure'],
    owasp: ['Broken Authentication', 'Sensitive Data Exposure', 'XML External Entities', 'Insecure Deserialization'],
    ssl: ['Weak Cipher Suite', 'Certificate Expiring Soon', 'Self-signed Certificate', 'Heartbleed Vulnerability']
  };
  
  return Array.from({ length: count }, (_, i) => {
    const severity = severityLevels[Math.floor(Math.random() * 5)];
    const name = vulnerabilityNames[toolType][Math.floor(Math.random() * vulnerabilityNames[toolType].length)];
    
    return {
      id: `vuln-${toolType}-${i}`,
      name,
      description: `This is a mock ${severity} vulnerability found by ${toolType}.`,
      severity,
      location: `/page${Math.floor(Math.random() * 5)}.html`,
      tool: toolType,
      cve: Math.random() > 0.3 ? `CVE-202${Math.floor(Math.random() * 4)}-${Math.floor(Math.random() * 10000)}` : undefined,
      remediation: Math.random() > 0.2 ? 'Update the software to the latest version.' : undefined
    };
  });
};

const generateMockPorts = (count: number): PortInfo[] => {
  const commonPorts = [21, 22, 23, 25, 53, 80, 110, 143, 443, 465, 587, 993, 995, 3306, 3389, 5432, 8080];
  const services = ['ftp', 'ssh', 'telnet', 'smtp', 'dns', 'http', 'pop3', 'imap', 'https', 'smtps', 'submission', 'imaps', 'pop3s', 'mysql', 'rdp', 'postgresql', 'http-proxy'];
  const states = ['open', 'closed', 'filtered'];
  
  return Array.from({ length: count }, (_, i) => {
    const portIndex = Math.floor(Math.random() * commonPorts.length);
    return {
      port: commonPorts[portIndex],
      service: services[portIndex],
      state: states[Math.floor(Math.random() * states.length)] as 'open' | 'closed' | 'filtered',
      version: Math.random() > 0.5 ? `${services[portIndex]}-${Math.floor(Math.random() * 10)}.${Math.floor(Math.random() * 10)}` : undefined
    };
  });
};

// Function to convert a URL to an IP address (mock)
const resolveDns = (url: string): string => {
  // Remove any protocol and path parts
  const domain = url.replace(/^https?:\/\//, '').split('/')[0];
  
  // Generate a mock IP address
  return `192.168.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
};

// Calculate security score based on vulnerabilities
const calculateSecurityScore = (vulnerabilities: Vulnerability[]): number => {
  const weights = {
    critical: 10,
    high: 5,
    medium: 2,
    low: 1,
    info: 0
  };
  
  const maxScore = 100;
  const totalVulnerabilities = vulnerabilities.length;
  
  if (totalVulnerabilities === 0) return maxScore;
  
  let weightedSum = 0;
  vulnerabilities.forEach(vuln => {
    weightedSum += weights[vuln.severity];
  });
  
  // Adjust score based on weighted vulnerabilities (more severe = lower score)
  const adjustedScore = maxScore - Math.min(weightedSum, maxScore);
  
  return Math.max(0, adjustedScore);
};

// Mock scan function
export const mockScan = async (
  url: string, 
  options: ScanOptions, 
  progressCallback: (progress: number) => void
): Promise<ScanResult> => {
  // Validate URL
  if (!url) throw new Error('URL is required');
  
  // Add protocol if missing
  const formattedUrl = url.startsWith('http') ? url : `https://${url}`;
  
  // Resolve DNS (mock)
  const ipAddress = resolveDns(formattedUrl);
  
  // Generate random scan duration (3-15 seconds)
  const duration = 3000 + Math.random() * 12000;
  
  // Simulate scan process with progress updates
  return new Promise((resolve) => {
    let progress = 0;
    const startTime = Date.now();
    
    const interval = setInterval(() => {
      progress += Math.random() * 5;
      
      if (progress >= 100) {
        progress = 100;
        clearInterval(interval);
        
        // Generate vulnerabilities for each tool
        let allVulnerabilities: Vulnerability[] = [];
        options.tools.forEach(tool => {
          // Generate more or fewer vulns based on depth
          const vulnCount = Math.floor(Math.random() * 10) + 
            (options.depth === 'light' ? 2 : options.depth === 'medium' ? 5 : 10);
          
          allVulnerabilities = [...allVulnerabilities, ...generateMockVulnerabilities(vulnCount, tool)];
        });
        
        // Generate ports (more for deeper scans)
        const portCount = options.depth === 'light' ? 5 : options.depth === 'medium' ? 10 : 20;
        const openPorts = generateMockPorts(portCount);
        
        // Calculate security score
        const securityScore = calculateSecurityScore(allVulnerabilities);
        
        // Create summary
        const summary = {
          total: allVulnerabilities.length,
          bySeverity: {
            critical: allVulnerabilities.filter(v => v.severity === 'critical').length,
            high: allVulnerabilities.filter(v => v.severity === 'high').length,
            medium: allVulnerabilities.filter(v => v.severity === 'medium').length,
            low: allVulnerabilities.filter(v => v.severity === 'low').length,
            info: allVulnerabilities.filter(v => v.severity === 'info').length,
          },
          byTool: options.tools.reduce<Partial<Record<ToolType, number>>>((acc, tool) => {
            acc[tool] = allVulnerabilities.filter(v => v.tool === tool).length;
            return acc;
          }, {})
        };
        
        // Prepare result
        const result: ScanResult = {
          id: `scan-${Date.now()}`,
          url: formattedUrl,
          ipAddress,
          scanDate: new Date(),
          duration: Date.now() - startTime,
          vulnerabilities: allVulnerabilities,
          openPorts,
          securityScore,
          tools: options.tools,
          summary
        };
        
        resolve(result);
      }
      
      progressCallback(progress);
    }, 200);
  });
};

export const exportScanResult = (scanResult: ScanResult, format: 'json' | 'csv' | 'pdf'): string => {
  // In a real application, this would generate the appropriate file format
  // For now, we'll just return a mock download URL
  return `data:application/${format};base64,mockExportData`;
};