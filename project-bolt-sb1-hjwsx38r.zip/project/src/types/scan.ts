export type ToolType = 'nmap' | 'wapiti' | 'nessus' | 'owasp' | 'ssl';
export type ScanDepth = 'light' | 'medium' | 'deep';
export type SeverityLevel = 'critical' | 'high' | 'medium' | 'low' | 'info';

export interface ScanOptions {
  tools: ToolType[];
  depth: ScanDepth;
  timeout: number;
}

export interface Vulnerability {
  id: string;
  name: string;
  description: string;
  severity: SeverityLevel;
  location: string;
  tool: ToolType;
  cve?: string;
  remediation?: string;
}

export interface PortInfo {
  port: number;
  service: string;
  state: 'open' | 'closed' | 'filtered';
  version?: string;
}

export interface ScanResult {
  id: string;
  url: string;
  ipAddress: string;
  scanDate: Date;
  duration: number;
  vulnerabilities: Vulnerability[];
  openPorts: PortInfo[];
  securityScore: number;
  tools: ToolType[];
  summary: {
    total: number;
    bySeverity: Record<SeverityLevel, number>;
    byTool: Partial<Record<ToolType, number>>;
  };
}