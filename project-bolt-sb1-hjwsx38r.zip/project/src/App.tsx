import React from 'react';
import { ThemeProvider } from './context/ThemeContext';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout/Layout';
import Dashboard from './pages/Dashboard/Dashboard';
import Reports from './pages/Reports/Reports';
import Vulnerabilities from './pages/Vulnerabilities/Vulnerabilities';
import History from './pages/History/History';
import Settings from './pages/Settings/Settings';
import { ScanProvider } from './context/ScanContext';

function App() {
  return (
    <BrowserRouter>
      <ThemeProvider>
        <ScanProvider>
          <Layout>
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/reports" element={<Reports />} />
              <Route path="/vulnerabilities" element={<Vulnerabilities />} />
              <Route path="/history" element={<History />} />
              <Route path="/settings" element={<Settings />} />
            </Routes>
          </Layout>
        </ScanProvider>
      </ThemeProvider>
    </BrowserRouter>
  );
}

export default App;