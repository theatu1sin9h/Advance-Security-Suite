import React, { useEffect, useRef } from 'react';
import { useTheme } from '../../context/ThemeContext';

interface SecurityScoreGaugeProps {
  score: number;
}

const SecurityScoreGauge: React.FC<SecurityScoreGaugeProps> = ({ score }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { theme } = useTheme();
  
  useEffect(() => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Set dimensions
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2 + 20; // Move center down to make room for text
    const radius = Math.min(centerX, centerY) - 30;
    
    // Draw outer arc background
    const startAngle = Math.PI;
    const endAngle = 2 * Math.PI;
    
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, startAngle, endAngle);
    ctx.lineWidth = 20;
    ctx.strokeStyle = theme === 'dark' ? '#374151' : '#E5E7EB';
    ctx.stroke();
    
    // Calculate score angle
    const scoreAngle = startAngle + (score / 100) * Math.PI;
    
    // Draw score arc
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, startAngle, scoreAngle);
    
    // Gradient based on score
    let gradient;
    if (score < 50) {
      gradient = ctx.createLinearGradient(0, 0, canvas.width, 0);
      gradient.addColorStop(0, '#EF4444'); // Red
      gradient.addColorStop(1, '#F97316'); // Orange
    } else if (score < 80) {
      gradient = ctx.createLinearGradient(0, 0, canvas.width, 0);
      gradient.addColorStop(0, '#F97316'); // Orange
      gradient.addColorStop(1, '#EAB308'); // Yellow
    } else {
      gradient = ctx.createLinearGradient(0, 0, canvas.width, 0);
      gradient.addColorStop(0, '#EAB308'); // Yellow
      gradient.addColorStop(1, '#22C55E'); // Green
    }
    
    ctx.lineWidth = 20;
    ctx.strokeStyle = gradient;
    ctx.stroke();
    
    // Draw score text
    ctx.font = 'bold 32px sans-serif';
    ctx.fillStyle = theme === 'dark' ? '#E5E7EB' : '#111827';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(score.toString(), centerX, centerY - 15);
    
    // Draw label text
    ctx.font = '14px sans-serif';
    ctx.fillStyle = theme === 'dark' ? '#9CA3AF' : '#6B7280';
    ctx.fillText('Security Score', centerX, centerY + 15);
    
    // Draw score category
    let category = '';
    if (score >= 90) category = 'Excellent';
    else if (score >= 80) category = 'Good';
    else if (score >= 60) category = 'Fair';
    else if (score >= 40) category = 'Poor';
    else category = 'Critical';
    
    ctx.font = 'bold 14px sans-serif';
    ctx.fillStyle = theme === 'dark' ? '#D1D5DB' : '#4B5563';
    ctx.fillText(category, centerX, centerY + 40);
    
    // Draw tick marks
    for (let i = 0; i <= 10; i++) {
      const angle = startAngle + (i / 10) * Math.PI;
      const x1 = centerX + (radius - 25) * Math.cos(angle);
      const y1 = centerY + (radius - 25) * Math.sin(angle);
      const x2 = centerX + (radius + 5) * Math.cos(angle);
      const y2 = centerY + (radius + 5) * Math.sin(angle);
      
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.lineWidth = i % 5 === 0 ? 3 : 1;
      ctx.strokeStyle = theme === 'dark' ? '#9CA3AF' : '#6B7280';
      ctx.stroke();
      
      // Add number labels at major ticks
      if (i % 5 === 0) {
        const labelX = centerX + (radius + 20) * Math.cos(angle);
        const labelY = centerY + (radius + 20) * Math.sin(angle);
        ctx.font = '12px sans-serif';
        ctx.fillStyle = theme === 'dark' ? '#9CA3AF' : '#6B7280';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText((i * 10).toString(), labelX, labelY);
      }
    }
    
  }, [score, theme]);
  
  return (
    <canvas ref={canvasRef} width={300} height={200} />
  );
};

export default SecurityScoreGauge;