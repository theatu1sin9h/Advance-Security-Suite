import React, { useEffect, useRef } from 'react';
import { useTheme } from '../../context/ThemeContext';

interface DataPoint {
  name: string;
  value: number;
  color: string;
}

interface SeverityPieChartProps {
  data: DataPoint[];
}

const SeverityPieChart: React.FC<SeverityPieChartProps> = ({ data }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { theme } = useTheme();
  
  useEffect(() => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Calculate total
    const total = data.reduce((sum, item) => sum + item.value, 0);
    
    if (total === 0) {
      // Draw empty circle
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      const radius = Math.min(centerX, centerY) - 10;
      
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI);
      ctx.strokeStyle = theme === 'dark' ? '#4B5563' : '#E5E7EB';
      ctx.lineWidth = 15;
      ctx.stroke();
      
      // Draw text
      ctx.font = 'bold 14px sans-serif';
      ctx.fillStyle = theme === 'dark' ? '#9CA3AF' : '#6B7280';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('No Data', centerX, centerY);
      
      return;
    }
    
    // Draw pie chart
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const radius = Math.min(centerX, centerY) - 10;
    
    let startAngle = 0;
    data.forEach(item => {
      if (item.value <= 0) return;
      
      const sliceAngle = (item.value / total) * 2 * Math.PI;
      
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, radius, startAngle, startAngle + sliceAngle);
      ctx.closePath();
      
      ctx.fillStyle = item.color;
      ctx.fill();
      
      startAngle += sliceAngle;
    });
    
    // Draw center circle (donut hole)
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius * 0.6, 0, 2 * Math.PI);
    ctx.fillStyle = theme === 'dark' ? '#1F2937' : '#FFFFFF';
    ctx.fill();
    
    // Draw total number in center
    ctx.font = 'bold 20px sans-serif';
    ctx.fillStyle = theme === 'dark' ? '#E5E7EB' : '#111827';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(total.toString(), centerX, centerY);
    
  }, [data, theme]);
  
  return (
    <div className="flex flex-col items-center">
      <canvas 
        ref={canvasRef} 
        width={200} 
        height={200}
        className="mb-3"
      />
      <div className="flex flex-wrap justify-center gap-3">
        {data.map((item, index) => (
          <div key={index} className="flex items-center text-xs">
            <div 
              className="w-3 h-3 rounded-sm mr-1" 
              style={{ backgroundColor: item.color }}
            ></div>
            <span>{item.name}: {item.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SeverityPieChart;