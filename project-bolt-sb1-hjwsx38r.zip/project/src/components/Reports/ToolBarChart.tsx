import React, { useEffect, useRef } from 'react';
import { useTheme } from '../../context/ThemeContext';

interface DataPoint {
  name: string;
  value: number;
}

interface ToolBarChartProps {
  data: DataPoint[];
}

const ToolBarChart: React.FC<ToolBarChartProps> = ({ data }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { theme } = useTheme();
  
  useEffect(() => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Check if we have data
    if (data.length === 0) {
      ctx.font = 'bold 14px sans-serif';
      ctx.fillStyle = theme === 'dark' ? '#9CA3AF' : '#6B7280';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('No Data', canvas.width / 2, canvas.height / 2);
      return;
    }
    
    // Sort data by value (descending)
    const sortedData = [...data].sort((a, b) => b.value - a.value);
    
    // Calculate max value for scaling
    const maxValue = Math.max(...sortedData.map(item => item.value));
    
    // Set chart dimensions
    const padding = 40;
    const barWidth = (canvas.width - 2 * padding) / sortedData.length - 10;
    const barMaxHeight = canvas.height - 2 * padding;
    
    // Draw horizontal gridlines
    const gridLineCount = 5;
    ctx.beginPath();
    for (let i = 0; i <= gridLineCount; i++) {
      const y = padding + (barMaxHeight * i) / gridLineCount;
      ctx.moveTo(padding, y);
      ctx.lineTo(canvas.width - padding, y);
    }
    ctx.strokeStyle = theme === 'dark' ? 'rgba(75, 85, 99, 0.2)' : 'rgba(229, 231, 235, 0.5)';
    ctx.lineWidth = 1;
    ctx.stroke();
    
    // Draw bars
    sortedData.forEach((item, index) => {
      const barHeight = (item.value / maxValue) * barMaxHeight;
      const x = padding + index * ((canvas.width - 2 * padding) / sortedData.length);
      const y = canvas.height - padding - barHeight;
      
      // Draw bar
      ctx.fillStyle = '#3B82F6';
      ctx.fillRect(x, y, barWidth, barHeight);
      
      // Draw value on top of bar
      ctx.font = '12px sans-serif';
      ctx.fillStyle = theme === 'dark' ? '#E5E7EB' : '#111827';
      ctx.textAlign = 'center';
      ctx.fillText(item.value.toString(), x + barWidth / 2, y - 5);
      
      // Draw label below bar
      ctx.font = '10px sans-serif';
      ctx.fillStyle = theme === 'dark' ? '#9CA3AF' : '#6B7280';
      ctx.textAlign = 'center';
      ctx.fillText(item.name, x + barWidth / 2, canvas.height - padding + 15);
    });
    
  }, [data, theme]);
  
  return (
    <canvas ref={canvasRef} width={300} height={200} />
  );
};

export default ToolBarChart;