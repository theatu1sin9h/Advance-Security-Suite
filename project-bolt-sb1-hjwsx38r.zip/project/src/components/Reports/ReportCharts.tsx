import React from 'react';
import { ScanResult, SeverityLevel } from '../../types/scan';
import SeverityPieChart from './SeverityPieChart';
import ToolBarChart from './ToolBarChart';
import SecurityScoreGauge from './SecurityScoreGauge';

interface ReportChartsProps {
  scan: ScanResult;
  showFullReport: boolean;
}

const ReportCharts: React.FC<ReportChartsProps> = ({ scan, showFullReport }) => {
  // Process data for charts
  const severityData = [
    { name: 'Critical', value: scan.summary.bySeverity.critical, color: '#ef4444' },
    { name: 'High', value: scan.summary.bySeverity.high, color: '#f97316' },
    { name: 'Medium', value: scan.summary.bySeverity.medium, color: '#eab308' },
    { name: 'Low', value: scan.summary.bySeverity.low, color: '#3b82f6' },
    { name: 'Info', value: scan.summary.bySeverity.info, color: '#6b7280' },
  ];
  
  const toolData = Object.entries(scan.summary.byTool).map(([tool, count]) => ({
    name: tool.toUpperCase(),
    value: count,
  }));
  
  return (
    <div className={`grid grid-cols-1 ${showFullReport ? 'md:grid-cols-2' : ''} gap-6`}>
      <div className={`bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4 border border-gray-200 dark:border-gray-700 ${
        !showFullReport ? 'flex items-center justify-center' : ''
      }`}>
        <SecurityScoreGauge score={scan.securityScore} />
      </div>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4 border border-gray-200 dark:border-gray-700">
        <h3 className="text-sm font-medium mb-3">Vulnerabilities by Severity</h3>
        <SeverityPieChart data={severityData} />
      </div>
      
      {showFullReport && (
        <>
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4 border border-gray-200 dark:border-gray-700">
            <h3 className="text-sm font-medium mb-3">Vulnerabilities by Tool</h3>
            <ToolBarChart data={toolData} />
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4 border border-gray-200 dark:border-gray-700">
            <h3 className="text-sm font-medium mb-3">Security Recommendations</h3>
            <div className="space-y-3 text-sm">
              {scan.vulnerabilities.length > 0 ? (
                <>
                  <p className="font-medium">Top Priority Fixes:</p>
                  <ul className="list-disc pl-5 space-y-2">
                    {scan.vulnerabilities
                      .filter(v => v.severity === 'critical' || v.severity === 'high')
                      .slice(0, 3)
                      .map(v => (
                        <li key={v.id}>
                          <span className="font-medium">{v.name}</span>: {v.remediation || 'Update and patch affected components.'}
                        </li>
                      ))}
                  </ul>
                  
                  <p className="font-medium mt-4">General Recommendations:</p>
                  <ul className="list-disc pl-5 space-y-2">
                    <li>Implement regular security scanning as part of your CI/CD pipeline.</li>
                    <li>Keep all software components and dependencies up to date.</li>
                    <li>Configure proper access controls and firewall rules.</li>
                    <li>Implement strict Content Security Policy headers.</li>
                  </ul>
                </>
              ) : (
                <p>No specific recommendations at this time.</p>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default ReportCharts;