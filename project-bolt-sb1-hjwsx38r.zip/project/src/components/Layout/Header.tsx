import React from 'react';
import { Shield, Moon, Sun, Settings } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';

const Header: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  
  return (
    <header className={`
      sticky top-0 z-10 px-4 py-3 
      ${theme === 'dark' ? 'bg-gray-800 text-white' : 'bg-white text-gray-900'} 
      shadow-md transition-colors duration-300 flex items-center justify-between
    `}>
      <div className="flex items-center space-x-2">
        <Shield className="h-7 w-7 text-blue-500" />
        <h1 className="text-xl font-bold">Advanced Security Suite</h1>
      </div>
      
      <div className="flex items-center space-x-4">
        <button 
          onClick={toggleTheme}
          className={`
            p-2 rounded-full transition-colors duration-200
            ${theme === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-200'}
          `}
          aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
        >
          {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
        </button>
        
        <button 
          className={`
            p-2 rounded-full transition-colors duration-200
            ${theme === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-200'}
          `}
          aria-label="Settings"
        >
          <Settings size={20} />
        </button>
      </div>
    </header>
  );
};

export default Header;