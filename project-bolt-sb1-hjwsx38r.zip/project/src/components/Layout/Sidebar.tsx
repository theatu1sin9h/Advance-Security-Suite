import React, { useState } from 'react';
import { Search, BarChart2, Shield, History, Settings, ChevronLeft, ChevronRight } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import { useNavigate, useLocation } from 'react-router-dom';

const Sidebar: React.FC = () => {
  const { theme } = useTheme();
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  
  const navItems = [
    { icon: <Search size={20} />, label: 'Scan', path: '/' },
    { icon: <BarChart2 size={20} />, label: 'Reports', path: '/reports' },
    { icon: <Shield size={20} />, label: 'Vulnerabilities', path: '/vulnerabilities' },
    { icon: <History size={20} />, label: 'History', path: '/history' },
    { icon: <Settings size={20} />, label: 'Settings', path: '/settings' },
  ];
  
  return (
    <div 
      className={`
        relative ${collapsed ? 'w-16' : 'w-64'} 
        ${theme === 'dark' ? 'bg-gray-800 text-white' : 'bg-white text-gray-900'} 
        transition-all duration-300 ease-in-out h-[calc(100vh-56px)] shadow-md
      `}
    >
      <div className="py-6 flex flex-col h-full">
        <nav className="space-y-1 px-2">
          {navItems.map((item) => (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`
                w-full flex items-center px-2 py-3 rounded-md transition-colors duration-200
                ${location.pathname === item.path ? 
                  'bg-blue-600 text-white' : 
                  (theme === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-200')
                }
              `}
            >
              <div className="flex items-center justify-center w-8">
                {item.icon}
              </div>
              {!collapsed && (
                <span className="ml-3 text-sm font-medium">{item.label}</span>
              )}
            </button>
          ))}
        </nav>
        
        <div className="mt-auto mb-6 px-2">
          <button 
            onClick={() => setCollapsed(prev => !prev)}
            className={`
              absolute right-0 top-10 transform translate-x-1/2
              p-1 rounded-full shadow-md 
              ${theme === 'dark' ? 'bg-gray-700 text-white' : 'bg-white text-gray-900'}
            `}
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;