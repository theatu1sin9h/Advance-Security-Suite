import React, { useState } from 'react';
import { PortInfo } from '../../types/scan';
import { ArrowUpDown, Search } from 'lucide-react';

interface PortsTableProps {
  ports: PortInfo[];
}

const PortsTable: React.FC<PortsTableProps> = ({ ports }) => {
  const [filter, setFilter] = useState('');
  const [sortField, setSortField] = useState<keyof PortInfo>('port');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  
  const handleSort = (field: keyof PortInfo) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };
  
  // Filter ports
  const filteredPorts = ports.filter(port => 
    port.port.toString().includes(filter) ||
    port.service.toLowerCase().includes(filter.toLowerCase()) ||
    port.state.toLowerCase().includes(filter.toLowerCase()) ||
    (port.version && port.version.toLowerCase().includes(filter.toLowerCase()))
  );
  
  // Sort ports
  const sortedPorts = [...filteredPorts].sort((a, b) => {
    if (a[sortField] < b[sortField]) return sortDirection === 'asc' ? -1 : 1;
    if (a[sortField] > b[sortField]) return sortDirection === 'asc' ? 1 : -1;
    return 0;
  });
  
  return (
    <div>
      <div className="mb-4">
        <div className="relative">
          <input
            type="text"
            value={filter}
            onChange={e => setFilter(e.target.value)}
            placeholder="Search ports, services, or state..."
            className="w-full px-4 py-2 pr-10 rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
          />
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
        </div>
      </div>
      
      <div className="overflow-x-auto rounded-lg border border-gray-200 dark:border-gray-700">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-800">
            <tr>
              <th
                scope="col"
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('port')}
              >
                <div className="flex items-center">
                  Port
                  <ArrowUpDown size={14} className="ml-1" />
                </div>
              </th>
              <th
                scope="col"
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('service')}
              >
                <div className="flex items-center">
                  Service
                  <ArrowUpDown size={14} className="ml-1" />
                </div>
              </th>
              <th
                scope="col"
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('state')}
              >
                <div className="flex items-center">
                  State
                  <ArrowUpDown size={14} className="ml-1" />
                </div>
              </th>
              <th
                scope="col"
                className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider"
              >
                Version
              </th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-800">
            {sortedPorts.map((port, index) => (
              <tr key={index} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  {port.port}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm">
                  {port.service}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm">
                  <span 
                    className={`inline-flex px-2 py-1 text-xs rounded-full ${
                      port.state === 'open' 
                        ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300' 
                        : port.state === 'filtered'
                        ? 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-300'
                        : 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-300'
                    }`}
                  >
                    {port.state}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                  {port.version || 'Unknown'}
                </td>
              </tr>
            ))}
            
            {sortedPorts.length === 0 && (
              <tr>
                <td colSpan={4} className="px-6 py-4 text-center text-sm text-gray-500 dark:text-gray-400">
                  No ports match your search
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default PortsTable;