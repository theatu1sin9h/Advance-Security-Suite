import React from 'react';
import { useScan } from '../../context/ScanContext';
import { formatDistance } from '../../utils/dateUtils';
import { History } from 'lucide-react';

interface ScanHistoryProps {
  className?: string;
}

const ScanHistory: React.FC<ScanHistoryProps> = ({ className }) => {
  const { scanResults, selectScan, currentScan } = useScan();
  
  if (scanResults.length === 0) {
    return null;
  }
  
  return (
    <div className={`bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 ${className}`}>
      <div className="flex items-center mb-4">
        <History size={18} className="mr-2 text-blue-500" />
        <h2 className="text-lg font-semibold">Recent Scans</h2>
      </div>
      
      <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
        {scanResults.map(scan => (
          <button
            key={scan.id}
            onClick={() => selectScan(scan.id)}
            className={`
              w-full text-left p-3 rounded-md transition-colors duration-200
              ${currentScan?.id === scan.id 
                ? 'bg-blue-100 dark:bg-blue-900 border-l-4 border-blue-500' 
                : 'bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-650'}
            `}
          >
            <div className="flex justify-between items-start">
              <div className="truncate flex-1">
                <div className="font-medium truncate">{scan.url}</div>
                <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  {formatDistance(scan.scanDate)} | {scan.ipAddress}
                </div>
              </div>
              <div className="ml-2 flex-shrink-0">
                <span 
                  className={`
                    inline-block w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium text-white
                    ${scan.securityScore >= 80 ? 'bg-green-500' : 
                      scan.securityScore >= 60 ? 'bg-yellow-500' : 'bg-red-500'}
                  `}
                >
                  {scan.securityScore}
                </span>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default ScanHistory;