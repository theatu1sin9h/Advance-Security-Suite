import React, { useState } from 'react';
import { useScan } from '../../context/ScanContext';
import { Search, Settings, Loader } from 'lucide-react';
import { ToolType, ScanDepth } from '../../types/scan';
import ProgressBar from '../UI/ProgressBar';

const ScanForm: React.FC = () => {
  const { scanOptions, setScanOptions, startScan, isScanning, scanProgress } = useScan();
  const [url, setUrl] = useState('');
  const [showOptions, setShowOptions] = useState(false);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (url && !isScanning) {
      startScan(url);
    }
  };
  
  const handleToolToggle = (tool: ToolType) => {
    setScanOptions({
      tools: scanOptions.tools.includes(tool)
        ? scanOptions.tools.filter(t => t !== tool)
        : [...scanOptions.tools, tool]
    });
  };
  
  const handleDepthChange = (depth: ScanDepth) => {
    setScanOptions({ depth });
  };
  
  const handleTimeoutChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value) && value > 0) {
      setScanOptions({ timeout: value });
    }
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 transition-all duration-300">
      <h2 className="text-lg font-semibold mb-4">Website Security Scanner</h2>
      
      <form onSubmit={handleSubmit}>
        <div className="relative">
          <input
            type="text"
            value={url}
            onChange={e => setUrl(e.target.value)}
            placeholder="Enter website URL (e.g., example.com)"
            className="w-full px-4 py-2 pr-10 rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            disabled={isScanning}
          />
          <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
        </div>
        
        {isScanning ? (
          <div className="mt-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium">Scanning in progress...</span>
              <span className="text-sm">{Math.round(scanProgress)}%</span>
            </div>
            <ProgressBar progress={scanProgress} />
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between mt-4">
              <button
                type="button"
                onClick={() => setShowOptions(!showOptions)}
                className="text-sm text-blue-500 dark:text-blue-400 flex items-center"
              >
                <Settings size={14} className="mr-1" />
                {showOptions ? 'Hide Options' : 'Show Options'}
              </button>
              
              <button
                type="submit"
                disabled={!url}
                className={`
                  px-4 py-2 rounded-md text-white font-medium transition-colors duration-200
                  ${!url ? 'bg-gray-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'}
                `}
              >
                Start Scan
              </button>
            </div>
            
            {showOptions && (
              <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <div className="mb-4">
                  <label className="block text-sm font-medium mb-2">Scanning Tools</label>
                  <div className="flex flex-wrap gap-2">
                    {(['nmap', 'wapiti', 'nessus', 'owasp', 'ssl'] as ToolType[]).map(tool => (
                      <button
                        key={tool}
                        type="button"
                        onClick={() => handleToolToggle(tool)}
                        className={`
                          px-3 py-1 text-xs rounded-full capitalize
                          ${scanOptions.tools.includes(tool)
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-gray-200'}
                        `}
                      >
                        {tool}
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="mb-4">
                  <label className="block text-sm font-medium mb-2">Scan Depth</label>
                  <div className="flex gap-2">
                    {(['light', 'medium', 'deep'] as ScanDepth[]).map(depth => (
                      <button
                        key={depth}
                        type="button"
                        onClick={() => handleDepthChange(depth)}
                        className={`
                          px-3 py-1 text-xs rounded-md capitalize
                          ${scanOptions.depth === depth
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-gray-200'}
                        `}
                      >
                        {depth}
                      </button>
                    ))}
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-2">
                    Timeout (seconds): {scanOptions.timeout}
                  </label>
                  <input
                    type="range"
                    min="10"
                    max="300"
                    step="10"
                    value={scanOptions.timeout}
                    onChange={handleTimeoutChange}
                    className="w-full"
                  />
                </div>
              </div>
            )}
          </>
        )}
      </form>
    </div>
  );
};

export default ScanForm;