import React, { useState } from 'react';
import { useScan } from '../../context/ScanContext';
import { Layers, Shield, Server, FileText, Download } from 'lucide-react';
import VulnerabilityList from '../Vulnerabilities/VulnerabilityList';
import PortsTable from '../Vulnerabilities/PortsTable';
import ReportCharts from '../Reports/ReportCharts';
import { exportScanResult } from '../../services/scanService';
import { LoadingSpinner } from '../UI/LoadingSpinner';

const ScanResultsPanel: React.FC = () => {
  const { currentScan, isScanning } = useScan();
  const [activeTab, setActiveTab] = useState('overview');
  
  if (isScanning) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 flex flex-col items-center justify-center min-h-[500px]">
        <LoadingSpinner size="large" />
        <p className="mt-4 text-lg">Scanning in progress...</p>
        <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
          This may take a few minutes depending on the scan depth
        </p>
      </div>
    );
  }
  
  if (!currentScan) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 flex flex-col items-center justify-center min-h-[500px]">
        <Shield size={48} className="text-gray-300 dark:text-gray-600 mb-4" />
        <p className="text-lg text-gray-500 dark:text-gray-400">No scan results to display</p>
        <p className="mt-2 text-sm text-gray-400 dark:text-gray-500">
          Enter a URL and start a scan to see the results here
        </p>
      </div>
    );
  }
  
  const handleExport = (format: 'json' | 'csv' | 'pdf') => {
    const url = exportScanResult(currentScan, format);
    // In a real app, this would trigger a download
    alert(`Exporting report in ${format.toUpperCase()} format`);
  };
  
  // Calculate aggregate statistics
  const { summary } = currentScan;
  const criticalCount = summary.bySeverity.critical;
  const highCount = summary.bySeverity.high;
  const mediumCount = summary.bySeverity.medium;
  const lowCount = summary.bySeverity.low;
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden transition-all duration-300">
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold">{currentScan.url}</h2>
            <div className="flex items-center text-sm text-gray-500 dark:text-gray-400 mt-1">
              <span className="mr-3">IP: {currentScan.ipAddress}</span>
              <span className="mr-3">Scanned: {new Date(currentScan.scanDate).toLocaleString()}</span>
              <span>Duration: {(currentScan.duration / 1000).toFixed(1)}s</span>
            </div>
          </div>
          
          <div className="flex items-center">
            <div className="mr-4">
              <div className="text-2xl font-bold text-center">
                <span 
                  className={
                    currentScan.securityScore >= 80 ? 'text-green-500' : 
                    currentScan.securityScore >= 60 ? 'text-yellow-500' : 'text-red-500'
                  }
                >
                  {currentScan.securityScore}
                </span>
              </div>
              <div className="text-xs text-gray-500 dark:text-gray-400">Security Score</div>
            </div>
            
            <div className="relative group">
              <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700">
                <Download size={20} />
              </button>
              <div className="absolute right-0 mt-2 w-36 bg-white dark:bg-gray-800 shadow-lg rounded-md overflow-hidden z-10 hidden group-hover:block">
                <button 
                  onClick={() => handleExport('pdf')}
                  className="w-full px-4 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700 text-sm"
                >
                  Export as PDF
                </button>
                <button 
                  onClick={() => handleExport('csv')}
                  className="w-full px-4 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700 text-sm"
                >
                  Export as CSV
                </button>
                <button 
                  onClick={() => handleExport('json')}
                  className="w-full px-4 py-2 text-left hover:bg-gray-100 dark:hover:bg-gray-700 text-sm"
                >
                  Export as JSON
                </button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-3 mt-4">
          <div className="bg-red-50 dark:bg-red-900/20 text-red-800 dark:text-red-300 px-3 py-1 rounded-full text-xs font-medium">
            Critical: {criticalCount}
          </div>
          <div className="bg-orange-50 dark:bg-orange-900/20 text-orange-800 dark:text-orange-300 px-3 py-1 rounded-full text-xs font-medium">
            High: {highCount}
          </div>
          <div className="bg-yellow-50 dark:bg-yellow-900/20 text-yellow-800 dark:text-yellow-300 px-3 py-1 rounded-full text-xs font-medium">
            Medium: {mediumCount}
          </div>
          <div className="bg-blue-50 dark:bg-blue-900/20 text-blue-800 dark:text-blue-300 px-3 py-1 rounded-full text-xs font-medium">
            Low: {lowCount}
          </div>
        </div>
      </div>
      
      <div className="border-b border-gray-200 dark:border-gray-700">
        <nav className="flex">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors duration-200 ${
              activeTab === 'overview'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            <span className="flex items-center"><Layers size={16} className="mr-2" /> Overview</span>
          </button>
          <button
            onClick={() => setActiveTab('vulnerabilities')}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors duration-200 ${
              activeTab === 'vulnerabilities'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            <span className="flex items-center"><Shield size={16} className="mr-2" /> Vulnerabilities</span>
          </button>
          <button
            onClick={() => setActiveTab('ports')}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors duration-200 ${
              activeTab === 'ports'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            <span className="flex items-center"><Server size={16} className="mr-2" /> Open Ports</span>
          </button>
          <button
            onClick={() => setActiveTab('report')}
            className={`px-4 py-3 text-sm font-medium border-b-2 transition-colors duration-200 ${
              activeTab === 'report'
                ? 'border-blue-500 text-blue-600 dark:text-blue-400'
                : 'border-transparent text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300'
            }`}
          >
            <span className="flex items-center"><FileText size={16} className="mr-2" /> Report</span>
          </button>
        </nav>
      </div>
      
      <div className="p-4">
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold mb-3">Security Summary</h3>
              <ReportCharts scan={currentScan} showFullReport={false} />
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-3">Top Vulnerabilities</h3>
              <VulnerabilityList 
                vulnerabilities={currentScan.vulnerabilities
                  .filter(v => v.severity === 'critical' || v.severity === 'high')
                  .slice(0, 5)} 
                compact={true}
              />
              {currentScan.vulnerabilities.filter(v => v.severity === 'critical' || v.severity === 'high').length > 5 && (
                <button 
                  onClick={() => setActiveTab('vulnerabilities')}
                  className="mt-2 text-blue-500 dark:text-blue-400 text-sm"
                >
                  View all vulnerabilities
                </button>
              )}
            </div>
          </div>
        )}
        
        {activeTab === 'vulnerabilities' && (
          <VulnerabilityList vulnerabilities={currentScan.vulnerabilities} />
        )}
        
        {activeTab === 'ports' && (
          <PortsTable ports={currentScan.openPorts} />
        )}
        
        {activeTab === 'report' && (
          <ReportCharts scan={currentScan} showFullReport={true} />
        )}
      </div>
    </div>
  );
};

export default ScanResultsPanel;