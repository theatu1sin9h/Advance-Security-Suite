import React, { createContext, useState, useContext, ReactNode } from 'react';
import { ScanResult, ScanOptions, ToolType } from '../types/scan';
import { mockScan } from '../services/scanService';

interface ScanContextType {
  isScanning: boolean;
  scanProgress: number;
  scanResults: ScanResult[];
  currentScan: ScanResult | null;
  scanOptions: ScanOptions;
  startScan: (url: string) => Promise<void>;
  setScanOptions: (options: Partial<ScanOptions>) => void;
  selectScan: (id: string) => void;
}

const defaultScanOptions: ScanOptions = {
  tools: ['nmap', 'wapiti'],
  depth: 'medium',
  timeout: 60,
};

const ScanContext = createContext<ScanContextType | undefined>(undefined);

export const ScanProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isScanning, setIsScanning] = useState(false);
  const [scanProgress, setScanProgress] = useState(0);
  const [scanResults, setScanResults] = useState<ScanResult[]>([]);
  const [currentScan, setCurrentScan] = useState<ScanResult | null>(null);
  const [scanOptions, setScanOptions] = useState<ScanOptions>(defaultScanOptions);

  const startScan = async (url: string) => {
    setIsScanning(true);
    setScanProgress(0);
    
    // Simulate progress updates
    const progressInterval = setInterval(() => {
      setScanProgress(prev => {
        const newProgress = prev + (Math.random() * 5);
        return newProgress >= 100 ? 100 : newProgress;
      });
    }, 300);
    
    try {
      // Simulate network delay and processing time
      const result = await mockScan(url, scanOptions, (progress) => {
        setScanProgress(progress);
      });
      
      setScanResults(prev => [result, ...prev]);
      setCurrentScan(result);
    } catch (error) {
      console.error('Scan failed:', error);
    } finally {
      clearInterval(progressInterval);
      setIsScanning(false);
      setScanProgress(100);
    }
  };

  const updateScanOptions = (options: Partial<ScanOptions>) => {
    setScanOptions(prev => ({ ...prev, ...options }));
  };

  const selectScan = (id: string) => {
    const scan = scanResults.find(scan => scan.id === id);
    if (scan) {
      setCurrentScan(scan);
    }
  };

  return (
    <ScanContext.Provider 
      value={{ 
        isScanning, 
        scanProgress, 
        scanResults, 
        currentScan,
        scanOptions,
        startScan,
        setScanOptions: updateScanOptions,
        selectScan
      }}
    >
      {children}
    </ScanContext.Provider>
  );
};

export const useScan = (): ScanContextType => {
  const context = useContext(ScanContext);
  if (!context) {
    throw new Error('useScan must be used within a ScanProvider');
  }
  return context;
};